import React from "react";
import "./Card.css";
import Card from "./MemberCard";
import debashan from "../../img/debashan.jpg";

function TeamMember() {
  return (
    <div className="card__container">
      <Card
        image={debashan}
        name="Debashan China"
        position="Founder"
        summary={[
          `Started entrepreneural journey from 2nd year of college. Started with a b2c startup from scratch with a team of 6+ people. And now landed with a AI based startup, NeyX, with 15+ members. 
        Always passionate about good people and good work. Meeting and having wonderful conversation with new interesting people is a hobby. 
        Bringing revolution to e-commerce. Changing the way we shop online.`,
          <br />,
          "Cheers to happiness and life.",
        ]}
        linkedin="https://www.linkedin.com/in/debashan"
        facebook="https://www.facebook.com/debashan.china.9"
        instagram="https://www.instagram.com/debashan/"
      />

      <Card
        image="https://i.pinimg.com/236x/bd/85/47/bd8547ddec0081974301de3cb90055e6.jpg"
        name="Aryan Sakhala"
        position="ML Developer"
        summary="I am Aryan Sakhala. I am pursuing computer engineering. I am currently in TE. I have achieved 9.05 CGPA in SE and 8.34 in FE.
        I have been part of NeyX since 03/2021. Furthermore, I am working towards specialization in Microscopic Neural Network."
        instagram="https://instagram.com/ryan.sakhala"
        github="https://www.github.com/"
        linkedin="https://www.linkedin.com/in/"
        // link={}
      />
    </div>
  );
}

export default TeamMember;

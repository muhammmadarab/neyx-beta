import React from "react";

function MemberCard(props) {
  return (
    <div className="card">
      <div className="card__image">
        <img src={props.image} alt={props.name} />
      </div>
      <div className="card__content">
        <h2>{props.name}</h2>
        <h3>{props.position}</h3>
        <p>{props.summary}</p>
        <div className="socialMedia">
          {props.facebook != null && (
            <a href={props.facebook}>
              <i className="fab fa-facebook-f"></i>
            </a>
          )}
          {props.instagram != null && (
            <a href={props.instagram}>
              <i className="fab fa-instagram"></i>
            </a>
          )}
          {props.github != null && (
            <a href={props.github}>
              <i className="fab fa-github"></i>
            </a>
          )}
          {props.linkedin != null && (
            <a href={props.linkedin}>
              <i className="fab fa-linkedin-in"></i>
            </a>
          )}
          {props.link != null && (
            <a href={props.link}>
              <i className="fa fa-link"></i>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

export default MemberCard;
